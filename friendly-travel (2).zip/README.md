# Friendly Travel - Site Web

Ce repository contient le site web complet de Friendly Travel, prêt à être publié sur GitHub Pages.

## Contenu
- index.html : page principale
- logo.png : placeholder logo
- image1.jpg, image2.jpg, image3.jpg : placeholders slider

## Mise en ligne
1. Créez un repository GitHub nommé 'friendly-travel'
2. Déposez tous les fichiers
3. Dans Settings -> Pages -> Source -> main branch
4. Votre site sera en ligne à https://<votre-nom-utilisateur>.github.io/friendly-travel/
